/**
    express admin
    动态组件 控制代码
 */
