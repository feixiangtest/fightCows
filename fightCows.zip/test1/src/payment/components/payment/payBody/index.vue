<template>

</template>
<script>
  import * as payMents from '@/base/config/payMent'
  export default {
    data () {
      return {}
    },
    methods: {},
    computed: {}
  }
</script>
