<template>
  <div id="promotionState">
    <!--推广管理列表页-->
    <div class="header yo-home-nav">
      <div class="center">
        <div class="hea-menu hea-left">
          <a href="javascript:;" @click="$router.go(-1)">
            <i class="yo-icon icon-arrows-left"></i>
          </a>
        </div>
        <div class="header-text titile">
          <h1>推广会员说明</h1>
        </div>
      </div>
    </div>
    <div class="content">
      <!-- 背景图 -->
      <div class="banner">
        <img src="/static/RESOURCE_VERSION/local/img/teamManage/什么是代理海报.jpg" alt>
      </div>
      <p class="description">您的账号既是玩家账号也是代理账号；既可以投注，
        也可以发展下级玩家，赚取返点佣金。
      </p>
      <div>
        <p class='title'>
          如何赚取返点？
        </p>
        <p>
          可获得的返点，等于自身返点与下级返点的差值，如自身返点5，下级返点3，你将能获得下级投注金额2%的返点，如下级投注100元，你将会获得2元。点击下级开户，可查看自身返点，也可为下级设置返点。
        </p>
      </div>
      <div>
        <p class='title'>
          如何赚取返点？
        </p>
        <p>
          可获得的返点，等于自身返点与下级返点的差值，如自身返点5，下级返点3，你将能获得下级投注金额2%的返点，如下级投注100元，你将会获得2元。点击下级开户，可查看自身返点，也可为下级设置返点。
        </p>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    data () {
      return {
  
      }
    },
  
    methods: {
  
    },
    mounted () {
    }
  }
</script>

