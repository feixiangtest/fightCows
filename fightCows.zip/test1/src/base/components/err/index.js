import err from './err.vue'
const AddErr = {
  install: function (Vue) {
    Vue.component('AddErr', err)
  }
}
export default AddErr
