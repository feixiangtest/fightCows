import opts from './opt.vue'
const optCom = {
  install: function (Vue) {
    Vue.component('optCom', opts)
  }
}
export default optCom
