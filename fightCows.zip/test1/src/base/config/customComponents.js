const outerArr = [
  'src/web/op/a04/components/home/main.vue'
]

const nodeCdnUrl = ''

export {
  outerArr,
  nodeCdnUrl
}
