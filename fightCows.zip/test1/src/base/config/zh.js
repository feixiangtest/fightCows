let pagezh = {
  'index': '',
  'promotion': '优惠活动',
  'favorite': '我的最爱',
  'browse': '最近浏览',
  'sports': '体育',
  'live': '真人视讯',
  'chessGame': '棋牌游戏',
  'fishingGame': '捕鱼游戏',
  'electronGame': '电子',
  'eGame': '电子游戏'
}

export { pagezh }
