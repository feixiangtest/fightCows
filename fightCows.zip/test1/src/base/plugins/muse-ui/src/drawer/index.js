import drawer from './drawer.vue'
const Drawer = {
  install: function (Vue) {
    Vue.component('Drawer', drawer)
  }
}
export default Drawer
