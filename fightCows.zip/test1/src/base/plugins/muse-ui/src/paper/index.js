export {default} from './paper'
