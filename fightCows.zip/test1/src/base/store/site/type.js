export const THIRD_ACTION = 'third.action' // 第三方跳转
export const THIRD_CHECK = 'check.action' // 判断是否登录方法
export const ISLOGIN_ACTION = 'isLogin.action' // 判断是否登录方法
