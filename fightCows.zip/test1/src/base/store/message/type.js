export const GAMEMESSAGE_ACTION = 'gameMessage.action'
export const GAMEMESSAGE_DETAIL = 'gameMessage.detail'
export const GAMEMESSAGE_UP = 'gameMessage.up'
