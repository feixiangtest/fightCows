// getPromotionLink
export const GET_PROMO_ACTION = 'getPromotion.action'
export const GET_PROMO_MUTATION = 'bettingRecord.mutation'
