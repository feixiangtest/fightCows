export const GET_PREVIEW_ACTION = 'loadPriviewTest.action'
export const GET_PREVIEW_MUTATION = 'loadPriviewTest.mutation'
