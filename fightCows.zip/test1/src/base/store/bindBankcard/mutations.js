// import * as types from './type'

export const state = {
  title: '', // 标题
  path: ''// 当前路径
}
export const mutations = {
}
