export const GET_BANKCARD = 'getBankList'
export const SAVE_BINDINFO = 'saveMemberinfo'
