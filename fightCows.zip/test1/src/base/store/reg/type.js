export const REG_GET = 'register'
export const REG_EMAIL = 'ConfirmEmail'
export const REG_SAVE = 'saveAccount'
export const WECHAT_GET = 'bingWechat'
