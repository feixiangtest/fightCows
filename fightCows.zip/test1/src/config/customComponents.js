const outerArr = [
  'src/op/a04/components/home/main.vue',
  'src/op/a04/pages/home.vue'
]

export {
  outerArr
}
