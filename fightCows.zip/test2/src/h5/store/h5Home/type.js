export const GET_PREVIEW_MUTATION = 'getPreview.mutation'
export const INITDATA = 'initH5Data.action'
export const INITDATA_DETAIL = 'initH5Data.detail'

export const INITSYSMESSAGE = 'initSysMessage.action'
export const INITSYSMESSAGE_MUTATION = 'initSysMessage.mutation'

export const H5UPDATEPERSONMSG = 'h5UpdatePersonMsg.action'

export const H5MSGCOUNT = 'h5MsgCount.action'
export const H5MSGCOUNT_MUTATION = 'h5MsgCount.mutation'
