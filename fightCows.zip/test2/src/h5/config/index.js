module.exports = {
  name: 'h5'	// 文件夹名称 和最后打包后文件夹的名称  /src/admin/
}
