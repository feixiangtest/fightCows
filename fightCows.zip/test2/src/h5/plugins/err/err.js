import err from './err1.vue'
const regErr = {
  install: function (Vue) {
    Vue.component('regErr', err)
  }
}
export default regErr
