<template>
	<div>
		搜索的内容
	</div>
</template>
<script>
	export default {
	  data () {
	    return {

	    }
	  },
	  methods: {
	
	  }
	}
</script>

