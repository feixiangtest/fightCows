module.exports = {
  name: 'alone'
}
