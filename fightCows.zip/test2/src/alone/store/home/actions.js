import * as types from './type'

let statusConst = window.common.statusConst

export const actions = {
}
