export const GETCONTENTBYID = 'help.getContentById'// 根据导航ID获取帮助中心文案或下级导航
export const GETNAVIGATIONMENU = 'help.getNavigationMenu' // 获取帮助中心导航
export const SEARCHARTICLE = 'help.searchArticle'// 根据内容搜索帮助中心文案
