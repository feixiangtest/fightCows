import { actions } from './actions'
import { state, mutations } from './mutations'

export default {
  actions,
  state,
  mutations
}
