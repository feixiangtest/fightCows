
export const INITDATA = 'initData.action'
export const INITDATA_DETAIL = 'initData.detail'

// 有效投注额记录
export const GETEFFICACBETTING_ACTION = 'getEfficacBetting.action'
export const GETEFFICACBETTING_MUTATION = 'getEfficacBetting.mutation'

export const H5MSGCOUNT = 'pcMsgCount.action'
export const H5MSGCOUNT_MUTATION = 'pcMsgCount.mutation'
