// 额度转换
export const MONEYCONVERSION_ACTION = 'moneyConversion.action'// 初始化额度转换数据
export const CONVERSIONTOTHIRD = 'moneyConversion.conversionToThird' // 将金额转到第三方
export const CHGTRANMONEYSTATUS = 'moneyConversion.chgTranMoneyStatus' // 切换自动手动
export const UPDATE_SESSION_MONEY_ACTION = 'updateSessionMoney.action' // 额度转换刷新余额
