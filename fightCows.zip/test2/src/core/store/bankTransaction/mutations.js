// import * as types from './type'

export const state = {
  // account: '',
  payment: ''
}
export const mutations = {

}
