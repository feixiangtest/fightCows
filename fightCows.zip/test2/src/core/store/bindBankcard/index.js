/**
 *  登录 和注册
 */
import { actions } from './actions'
import { state, mutations } from './mutations'

export default {
  actions,
  state,
  mutations
}
