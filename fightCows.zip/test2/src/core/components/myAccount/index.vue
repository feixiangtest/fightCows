<template>
  <div>

  </div>
</template>

<script>

export default {
  name: 'index',
  components: {

  },
  data () {
    return {

    }
  }
}
</script>
