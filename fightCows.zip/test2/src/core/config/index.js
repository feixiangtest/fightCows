module.exports = {
  name: 'core'
}
