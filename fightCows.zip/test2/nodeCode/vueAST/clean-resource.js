const path       = require("path");
const fs         = require("fs-extra")
fs.removeSync(path.resolve(__dirname, '../../resource/gulp'))
