/**
 域名 // 开头
 必须  / 结尾
 */
CDNMap = {
  cdnUrl: ''
}
